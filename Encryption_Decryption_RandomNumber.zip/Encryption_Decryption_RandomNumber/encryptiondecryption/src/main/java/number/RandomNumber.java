package number;

import java.util.Random;

public class RandomNumber{

	public static int randomNumber(int a, int b){
//		  a =18 ;
//		  b =10;
		Random random = new Random();
		int number = random.nextInt((b - a) + 1) + a;
	    return number;

	}

}
